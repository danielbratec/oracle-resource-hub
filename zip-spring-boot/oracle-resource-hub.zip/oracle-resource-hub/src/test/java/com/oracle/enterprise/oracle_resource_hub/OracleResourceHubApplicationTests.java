package com.oracle.enterprise.oracle_resource_hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OracleResourceHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
