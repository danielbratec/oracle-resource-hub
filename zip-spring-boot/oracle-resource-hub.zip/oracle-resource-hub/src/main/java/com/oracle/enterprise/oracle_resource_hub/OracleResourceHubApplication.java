package com.oracle.enterprise.oracle_resource_hub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OracleResourceHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(OracleResourceHubApplication.class, args);
	}

}
